package com.zebra.demo.rfidreader.rfid;

import android.os.AsyncTask;
import android.util.Log;

import com.zebra.demo.rfidreader.home.RFIDBaseActivity;
import com.zebra.demo.rfidreader.settings.InventoryProtocolFragment;
import com.zebra.demo.rfidreader.settings.ProfileFragmentRE40;
import com.zebra.rfid.api3.Antennas;
import com.zebra.rfid.api3.DYNAMIC_POWER_OPTIMIZATION;
import com.zebra.rfid.api3.ENUM_CONNECTION_MODE;
import com.zebra.rfid.api3.ENUM_TRIGGER_MODE;
import com.zebra.rfid.api3.INVENTORY_STATE;
import com.zebra.rfid.api3.InvalidUsageException;
import com.zebra.rfid.api3.LogStates;
import com.zebra.rfid.api3.OperationFailureException;
import com.zebra.rfid.api3.RFIDResults;
import com.zebra.rfid.api3.ReaderDevice;
import com.zebra.rfid.api3.RfidEventsListener;
import com.zebra.rfid.api3.SESSION;
import com.zebra.rfid.api3.VersionInfo;
import com.zebra.demo.application.Application;
import com.zebra.demo.rfidreader.common.LinkProfileUtil;

import java.util.ArrayList;

import static com.zebra.demo.rfidreader.rfid.RFIDController.CONNECT_RFID_WWAN;
import static com.zebra.demo.rfidreader.settings.ProfileContent.UpdateActiveProfile;
import static com.zebra.demo.rfidreader.settings.ProfileContent.UpdateProfilesForRegulatory;

public class ConnectionController {
    private static final String TAG = "ConnectionController";
    private int[] powerLevels;

    protected ConnectionController() {
    }


    public void AutoConnectDevice(final String password, final RfidEventsListener rfidEventsListener, final RfidListeners rfidListeners, final UpdateUIListener updateUIListener) {
        RFIDController.autoConnectDeviceTask = new AsyncTask<Void, Void, Boolean>() {
            @Override
            protected void onCancelled() {
                super.onCancelled();
                RFIDController.autoConnectDeviceTask = null;
                rfidListeners.onFailure((String) null);
            }

            OperationFailureException exception;
            InvalidUsageException exceptionIN;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();

            }

            @Override
            protected Boolean doInBackground(Void... params) {
                try {
                    if (RFIDController.readers != null && RFIDController.mConnectedReader == null/* && LAST_CONNECTED_READER.startsWith("RFD8500")*/) {
                        if (RFIDController.readers.GetAvailableRFIDReaderList() != null) {
                            RFIDController.mConnectedDevice = getConnectedDeviceFromRFIDReaderList(RFIDController.LAST_CONNECTED_READER);
                            if (RFIDController.mConnectedDevice != null) {
                                RFIDController.mConnectedReader = RFIDController.mConnectedDevice.getRFIDReader();
                                try {
                                    if (!RFIDController.mConnectedReader.isConnected() && !this.isCancelled()) {
                                        updateUIListener.updateProgressMessage(RFIDController.mConnectedReader.getHostName());
                                        RFIDController.mConnectedReader.setPassword(password);
                                        if(!CONNECT_RFID_WWAN)
                                            RFIDController.mConnectedReader.connect();
                                        else
                                            RFIDController.mConnectedReader.connect(ENUM_CONNECTION_MODE.RFID_WWAN);
                                    } else {
                                        this.cancel(true);
                                    }
                                } catch (NullPointerException e) {
                                    Log.d(RFIDController.TAG, "null pointer ");
                                    if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                                } catch (InvalidUsageException e) {
                                    if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                                } //catch (OperationFailureException e) {
//                                    if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
//                                    exception = e;
//                                }
                                try {
                                    if (RFIDController.mConnectedReader.Events != null) {
                                        RFIDController.mConnectedReader.Events.addEventsListener(rfidEventsListener);
                                    }
                                } catch (InvalidUsageException e) {
                                    if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                                } catch (OperationFailureException e) {
                                    if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                                } catch (NullPointerException e) {
                                    Log.d(RFIDController.TAG, "null pointer ");
                                    if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                                }
                                if (exception == null) {
                                    try {
                                        RFIDController.getInstance().updateReaderConnection(true);
                                    } catch (InvalidUsageException e) {
                                        if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                                    } catch (OperationFailureException e) {
                                        if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                                    } catch (NullPointerException e) {
                                        Log.d(RFIDController.TAG, "null pointer ");
                                        if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                                    }
                                } else {
                                    RFIDController.clearSettings();
                                }
                            }
                        }
                    }
                } catch (InvalidUsageException ex) {
                    exceptionIN = ex;
                } catch (OperationFailureException e) {
                    if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                    exception = e;
                }
                return null;
            }


            @Override
            protected void onPostExecute(Boolean result) {

                if (RFIDController.mConnectedReader != null && RFIDController.mConnectedReader.isConnected()) {
                    if (exception != null) {
                        if (exception.getResults() == RFIDResults.RFID_READER_REGION_NOT_CONFIGURED) {
                            try {
                                RFIDController.mConnectedReader.Events.addEventsListener(rfidEventsListener);
                            } catch (InvalidUsageException e) {
                                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                            } catch (OperationFailureException e) {
                                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }

                            }
                            RFIDController.regionNotSet = true;


                        } else if (exception.getResults() == RFIDResults.RFID_BATCHMODE_IN_PROGRESS) {
                            RFIDController.isBatchModeInventoryRunning = true;
                            RFIDController.mIsInventoryRunning = true;
                            try {
                                if (RFIDController.mConnectedReader.Events != null) {
                                    RFIDController.mConnectedReader.Events.addEventsListener(rfidEventsListener);
                                }
                                //MainActivity.updateReaderConnection(false);
                                RFIDController.mConnectedReader.Events.setBatchModeEvent(true);
                                RFIDController.mConnectedReader.Events.setReaderDisconnectEvent(true);
                                RFIDController.mConnectedReader.Events.setBatteryEvent(true);
                                RFIDController.mConnectedReader.Events.setInventoryStopEvent(true);
                                RFIDController.mConnectedReader.Events.setInventoryStartEvent(true);
                                RFIDController.mConnectedReader.Events.setTagReadEvent(true);
                                RFIDController.mConnectedReader.Events.setWPAEvent(true);
                                RFIDController.mConnectedReader.Events.setScanDataEvent(true);
                                RFIDController.mConnectedReader.Events.setIotEvent(true);
                                RFIDController.mConnectedReader.Events.setCertificateEvent(true);
                                RFIDController.mConnectedReader.Events.setConnectedInterfaceEvent(true);
                                RFIDController.mConnectedReader.Events.setDebugInfoEvent(true);
                            } catch (InvalidUsageException e) {
                                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                            } catch (OperationFailureException e) {
                                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                            } catch (NullPointerException e) {
                                Log.d(RFIDController.TAG, "null pointer ");
                                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                            }

                        } else {
                            try {
                                RFIDController.mConnectedReader.disconnect();
                            } catch (InvalidUsageException e) {
                                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                            } catch (OperationFailureException e) {
                                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                            }
                            RFIDController.mConnectedReader = null;
                            RFIDController.mConnectedDevice = null;
                        }
                        rfidListeners.onFailure(exception);
                    } else {
                        rfidListeners.onSuccess(null);
                    }


                } else {
                    rfidListeners.onFailure("Device is not paired");
                }
                RFIDController.autoConnectDeviceTask = null;
                //contextSettingDetails = null;
            }
        }.execute();

    }


    public void updateReaderConnection(Boolean fullUpdate) throws InvalidUsageException, OperationFailureException {
        if( RFIDController.mConnectedReader == null )
            return;
        boolean ngeErrorLogEnabled = RFIDController.mConnectedReader.Logger.getLogConfig(LogStates.NGEERRORLOGSTATE);
        boolean ngeLogEnabled = RFIDController.mConnectedReader.Logger.getLogConfig(LogStates.NGEPACKETLOGSTATE);
        RFIDController.mConnectedReader.Actions.enableNGEErrorLogs(ngeErrorLogEnabled);
        RFIDController.mConnectedReader.Actions.enableNGELogs(ngeLogEnabled);
        if (fullUpdate)
            RFIDController.mConnectedReader.PostConnectReaderUpdate();
        RFIDController.mConnectedReader.Events.setBatchModeEvent(true);
        RFIDController.mConnectedReader.Events.setReaderDisconnectEvent(true);
        RFIDController.mConnectedReader.Events.setInventoryStartEvent(true);
        RFIDController.mConnectedReader.Events.setInventoryStopEvent(true);
        RFIDController.mConnectedReader.Events.setTagReadEvent(true);
        RFIDController.mConnectedReader.Events.setHandheldEvent(true);
        RFIDController.mConnectedReader.Events.setBatteryEvent(true);
        RFIDController.mConnectedReader.Events.setPowerEvent(true);
        RFIDController.mConnectedReader.Events.setOperationEndSummaryEvent(true);
        RFIDController.mConnectedReader.Events.setWPAEvent(true);
        RFIDController.mConnectedReader.Events.setScanDataEvent(true);
        RFIDController.mConnectedReader.Events.setFirmwareUpdateEvent(true);
        RFIDController.mConnectedReader.Events.setIotEvent(true);
        RFIDController.mConnectedReader.Events.setCertificateEvent(true);
        RFIDController.mConnectedReader.Events.setConnectedInterfaceEvent(true);
        RFIDController.mConnectedReader.Events.setDebugInfoEvent(true);
        RFIDController.regulatory = RFIDController.mConnectedReader.Config.getRegulatoryConfig();
        RFIDController.regionNotSet = false;
        RFIDController.rfModeTable = RFIDController.mConnectedReader.ReaderCapabilities.RFModes.getRFModeTableInfo(0);
        LinkProfileUtil.getInstance().populateLinkeProfiles();

        RFIDBaseActivity.getInstance().LoadProfiles();
        LoadProfileToReader();
        String modelName = RFIDController.mConnectedDevice.getName();
        String model = RFIDController.mConnectedDevice.getDeviceCapability(modelName);
        if ("RE40".equalsIgnoreCase(model)) {
            ProfileFragmentRE40 contentRE40 = new ProfileFragmentRE40();
            contentRE40.saveDataToAntenna();
            RFIDController.hostBeeperVolume = RFIDController.mConnectedReader.Config.getBeeperVolume();
        }
        //
        RFIDController.antennaRfConfig = RFIDController.mConnectedReader.Config.Antennas.getAntennaRfConfig(1);
        RFIDController.singulationControl = RFIDController.mConnectedReader.Config.Antennas.getSingulationControl(1);
        RFIDController.settings_startTrigger = RFIDController.mConnectedReader.Config.getStartTrigger();
        RFIDController.settings_stopTrigger = RFIDController.mConnectedReader.Config.getStopTrigger();
        RFIDController.tagStorageSettings = RFIDController.mConnectedReader.Config.getTagStorageSettings();

        if (RFIDController.mConnectedReader.getHostName().startsWith("RFD8500")
        ||RFIDController.mConnectedReader.getHostName().startsWith("RFD40P")
        ||RFIDController.mConnectedReader.getHostName().startsWith("RFD40+")
        ||RFIDController.mConnectedReader.getHostName().startsWith("RFD90")) {
            // beeperVolume = BEEPER_VOLUME.QUIET_BEEP;
            RFIDController.dynamicPowerSettings = RFIDController.mConnectedReader.Config.getDPOState();
            RFIDController.sledBeeperVolume = RFIDController.mConnectedReader.Config.getBeeperVolume();
            RFIDController.batchMode = RFIDController.mConnectedReader.Config.getBatchModeConfig().getValue();
            RFIDController.mConnectedReader.Config.setTriggerMode(ENUM_TRIGGER_MODE.RFID_MODE, false);
            if (RFIDController.mConnectedReader.getHostName().startsWith("RFD8500") != true )
                RFIDController.usbBatchMode = RFIDController.mConnectedReader.Config.getUsbBatchModeConfig().getValue();
        }
        if(RFIDController.mConnectedReader.getTransport().equals("SERVICE_USB")) {
            RFIDController.sledBeeperVolume = RFIDController.mConnectedReader.Config.getBeeperVolume();
            RFIDController.batchMode = RFIDController.mConnectedReader.Config.getBatchModeConfig().getValue();
            RFIDController.usbBatchMode = RFIDController.mConnectedReader.Config.getUsbBatchModeConfig().getValue();
            RFIDController.hostBeeperVolume = RFIDController.mConnectedReader.Config.getBeeperVolume();
        }
        if ( RFIDController.mConnectedReader.getHostName().startsWith("RFD40+")
                ||RFIDController.mConnectedReader.getHostName().startsWith("RFD90")) {
            RFIDController.scanBatchMode = RFIDController.mConnectedReader.Config.getScanBatchModeConfig().getValue();
        }
        RFIDController.mConnectedReader.Config.getDeviceStatus(true, false, false);

        RFIDController.reportUniquetags = RFIDController.mConnectedReader.Config.getUniqueTagReport();
        try {
            RFIDController.mConnectedReader.Config.getDeviceVersionInfo(Application.versionInfo);
        } catch (OperationFailureException e) {
            Log.e(TAG, " Failed to get device version info: " + e.getVendorMessage() + " (" + e.getResults() + ")");
        } catch (InvalidUsageException e) {
            Log.e(TAG, " Invalid usage when getting device version info: " + e.getMessage());
        }

        RFIDController.mConnectedReader.Config.setLedBlinkEnable(RFIDController.ledState);

        if (InventoryProtocolFragment.isInventoryProtocolSupported()) {
            try {
                RFIDController.inventoryProtocol = RFIDController.mConnectedReader.Config.getInventoryProtocol();
            } catch (InvalidUsageException | OperationFailureException e) {
                Log.d(TAG, "Failed to read inventory protocol: " + e.getMessage());
            }
        }
//        RFIDController.mConnectedReader.Config.getDeviceStatus(true, false, false,true,true);

        //BatteryStatistics batStats = RFIDController.mConnectedReader.Config.getBatteryStats();

        if (RFIDController.ActiveProfile.content.equals("Reader Defined")) {
            UpdateActiveProfile();
        }
        VersionInfo sdkversion = null;
        if( RFIDController.mConnectedReader != null )
            sdkversion = RFIDController.mConnectedReader.versionInfo();



        //com.zebra.rfid.api3.BuildConfig.VERSION_NAME

        Log.d("DEMOAPP", "SDK version " + com.zebra.rfid.api3.BuildConfig.VERSION_NAME);
        RFIDController.startTimer();
    }

    void LoadProfileToReader() {
        // update profiles based on reader type
        UpdateProfilesForRegulatory();
        if (!RFIDController.ActiveProfile.content.equals("Reader Defined")) {
            try {
                for(short i = 1; i <= RFIDController.mConnectedReader.ReaderCapabilities.getNumAntennaSupported(); ++i) {
                // Antenna
                    Antennas.AntennaRfConfig antennaRfConfigLocal;
                    antennaRfConfigLocal = RFIDController.mConnectedReader.Config.Antennas.getAntennaRfConfig(i);

                    powerLevels = RFIDController.mConnectedReader.ReaderCapabilities.getTransmitPowerLevelValues();
                    antennaRfConfigLocal.setTransmitPowerIndex(getPowerLevelIndex(RFIDController.ActiveProfile.powerLevel));

                    antennaRfConfigLocal.setrfModeTableIndex(/*LinkProfileUtil.getInstance().getSimpleProfileModeIndex*/
                            (RFIDController.ActiveProfile.LinkProfileIndex));
                    RFIDController.mConnectedReader.Config.Antennas.setAntennaRfConfig(i, antennaRfConfigLocal);
                    RFIDController.antennaRfConfig = antennaRfConfigLocal;
                    // Singulation
                    Antennas.SingulationControl singulationControlLocal;

                    singulationControlLocal = RFIDController.mConnectedReader.Config.Antennas.getSingulationControl(i);
                    singulationControlLocal.setSession(SESSION.GetSession(RFIDController.ActiveProfile.SessionIndex));
                    if (RFIDController.ActiveProfile.id.equals("0"))
                        singulationControlLocal.Action.setInventoryState(INVENTORY_STATE.INVENTORY_STATE_AB_FLIP);
                    else if (!RFIDController.ActiveProfile.id.equals("5"))
                        singulationControlLocal.Action.setInventoryState(INVENTORY_STATE.INVENTORY_STATE_A);
                    // honour the prefilter over profile
                    if (RFIDController.mConnectedReader.Actions.PreFilters.length() > 0) {
                        com.zebra.rfid.api3.PreFilters.PreFilter prefilter1 = RFIDController.mConnectedReader.Actions.PreFilters.getPreFilter(0);
                        if (prefilter1 != null) {
                            if (RFIDController.NON_MATCHING)
                                singulationControlLocal.Action.setInventoryState(INVENTORY_STATE.INVENTORY_STATE_A);
                            else
                                singulationControlLocal.Action.setInventoryState(INVENTORY_STATE.INVENTORY_STATE_B);
                        }
                    }
                    RFIDController.mConnectedReader.Config.Antennas.setSingulationControl(i, singulationControlLocal);
                    RFIDController.singulationControl = singulationControlLocal;
                }
                // DPO
                if (RFIDController.ActiveProfile.DPO_On)
                    RFIDController.mConnectedReader.Config.setDPOState(DYNAMIC_POWER_OPTIMIZATION.ENABLE);
                else
                    RFIDController.mConnectedReader.Config.setDPOState(DYNAMIC_POWER_OPTIMIZATION.DISABLE);
                RFIDController.dynamicPowerSettings = RFIDController.mConnectedReader.Config.getDPOState();
            } catch (InvalidUsageException e) {
            } catch (OperationFailureException e) {
                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
            }
        }
    }

    private int getPowerLevelIndex(int powerLevel) {
        for (int i = 0; i < powerLevels.length; i++) {
            if (powerLevel == powerLevels[i]) {
                return i;
            }
        }
        return -1;
    }

    public static void operationHasAborted(final RfidListeners rfidListeners) {
        if (RFIDController.isBatchModeInventoryRunning != null && RFIDController.isBatchModeInventoryRunning) {
            if (RFIDController.isInventoryAborted) {
                RFIDController.isBatchModeInventoryRunning = false;
                RFIDController.isGettingTags = true;
                if (RFIDController.settings_startTrigger == null) {
                    new AsyncTask<Void, Void, Boolean>() {
                        @Override
                        protected Boolean doInBackground(Void... voids) {
                            try {
                                // execute following code after STOP is finished
                                synchronized (RFIDController.isInventoryAborted) {
                                    RFIDController.isInventoryAborted.wait(50);
                                }
                                if( RFIDController.mConnectedReader == null ) {
                                    RFIDController.getInstance().updateReaderConnection(true);
                                    RFIDController.getTagReportingFields();
                                    RFIDController.clearInventoryData();
                                    return null;
                                }
                                if (RFIDController.mConnectedReader.isCapabilitiesReceived()) {
                                    RFIDController.getInstance().updateReaderConnection(false);
                                } else {
                                    RFIDController.getInstance().updateReaderConnection(true);
                                }
                                RFIDController.getTagReportingFields();
                                RFIDController.mConnectedReader.Actions.getBatchedTags();
                            } catch (InvalidUsageException e) {
                                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                            } catch (OperationFailureException e) {
                                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                                Log.d(RFIDController.TAG, "OpFailEx " + e.getVendorMessage() + " " + e.getResults() + " " + e.getStatusDescription());
                            } catch (InterruptedException e) {
                                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                            }
                            return null;
                        }

                        @Override
                        protected void onPostExecute(Boolean aBoolean) {
                            super.onPostExecute(aBoolean);
                            rfidListeners.onSuccess(null);
                        }
                    }.execute();
                } else {
                    RFIDController.mConnectedReader.Actions.getBatchedTags();
                    rfidListeners.onSuccess(null);
                }
            } else
                rfidListeners.onSuccess(null);
        } else
            rfidListeners.onSuccess(null);

    }

    public ReaderDevice getConnectedDeviceFromRFIDReaderList(String deviceName) throws InvalidUsageException {
        ArrayList<ReaderDevice> readersListArray = RFIDController.readers.GetAvailableRFIDReaderList();
        if (readersListArray.size() == 1) {
            return readersListArray.get(0);
        } else {
            for (int prevreader = readersListArray.size() - 1; prevreader >= 0; prevreader--) {
                if (readersListArray.get(prevreader).getName().equals(deviceName)) {
                    return readersListArray.get(prevreader);
                }
            }
        }
        return null;
    }
}
