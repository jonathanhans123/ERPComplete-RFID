package com.zebra.demo.rfidreader.settings;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.slider.Slider;
import com.zebra.demo.ActiveDeviceActivity;
import com.zebra.rfid.api3.BEEPER_VOLUME;
import com.zebra.rfid.api3.InvalidUsageException;
import com.zebra.rfid.api3.OperationFailureException;
import com.zebra.demo.R;
import com.zebra.demo.rfidreader.common.Constants;
import com.zebra.demo.rfidreader.common.CustomProgressDialog;
import com.zebra.demo.rfidreader.rfid.RFIDController;
import com.zebra.rfid.api3.RFIDResults;
import static com.zebra.rfid.api3.GenericUtil.isCharmanderDevice;



import static com.zebra.demo.scanner.helpers.ActiveDeviceAdapter.MAIN_RFID_SETTINGS_TAB;

/**
 * A simple {@link androidx.fragment.app.Fragment} subclass.
 * <p/>
 * Use the {@link BeeperFragment#newInstance} factory method to
 * create an instance of this fragment.
 * <p/>
 * Fragment to show the UI for Beeper settings.
 */
public class BeeperFragment extends BackPressedFragment {
    private CheckBox sledBeeper;
    private CheckBox hostBeeper;
    private Spinner volumeSpinner;
    private TextView Volume;
    private TextView SledBeepertext;
    private ArrayAdapter<CharSequence> volumeAdapter;
    private SeekBar sledBeeperVolumeSeekBar;

    private Slider sledBeeperVolumeSlider;
    private TextView sledBeeperVolumeValue;
    private int sledBeeperVolume = 0;
    View sledBeeperVolumeRow;
    private static final String TAG = "BeeperFragment";
    RFIDResults result;

    public BeeperFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment BeeperFragment.
     */
    public static BeeperFragment newInstance() {
        return new BeeperFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_beeper, container, false);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        sledBeeper = (CheckBox) getActivity().findViewById(R.id.sledBeeper);
        hostBeeper = (CheckBox) getActivity().findViewById(R.id.hostBeeper);
        volumeSpinner = (Spinner) getActivity().findViewById(R.id.volumeSpinner);
        SledBeepertext =  (TextView) getActivity().findViewById(R.id.SledBeepertext);
        Volume = (TextView) getActivity().findViewById(R.id.Volume);
        sledBeeperVolumeRow = getActivity().findViewById(R.id.sledBeeperVolumeRow);
        sledBeeperVolumeSlider =
                getActivity().findViewById(R.id.sledBeeperVolumeSlider);
        sledBeeperVolumeValue =
                getActivity().findViewById(R.id.sledBeeperVolumeValue);
        if (RFIDController.mConnectedReader != null) {
            //if (!RFIDController.mConnectedReader.getHostName().startsWith("RFD8500")) {
            if (RFIDController.mConnectedReader.getHostName().startsWith("MC33")) {
                sledBeeper.setChecked(false);
                sledBeeper.setEnabled(false);
                hostBeeper.setEnabled(true);
            } else if (RFIDController.mConnectedReader.getHostName().startsWith("RFD40") || RFIDController.mConnectedReader.getHostName().startsWith("RFD90")) {
                sledBeeper.setEnabled(true);
                sledBeeper.setChecked(true);
                hostBeeper.setChecked(false);
            } else if ("RE40".equalsIgnoreCase(model) || isCharmanderDevice() ||"QC".equalsIgnoreCase(model)) {
                sledBeeper.setChecked(false);
                sledBeeper.setEnabled(false);
                volumeSpinner.setEnabled(false);
                Volume.setTextColor(Color.LTGRAY);
                SledBeepertext.setTextColor(Color.LTGRAY);
            }
        }


        hostBeeper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!("RE40".equalsIgnoreCase(model) || isCharmanderDevice()||"QC".equalsIgnoreCase(model))){
                    if (((CheckBox) view).isChecked() || sledBeeper.isChecked()) {
                        ((Spinner) volumeSpinner).getSelectedView().setEnabled(true);
                        volumeSpinner.setEnabled(true);
                    } else if (!sledBeeper.isChecked()) {
                        //   volumeSpinner.setVisibility(View.INVISIBLE);
                        ((Spinner) volumeSpinner).getSelectedView().setEnabled(false);
                        volumeSpinner.setEnabled(false);
                    }
                }
            }
        });
        sledBeeper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setSledVolumeControlsEnabled(((CheckBox)view).isChecked());

                if (((CheckBox) view).isChecked() || hostBeeper.isChecked()) {
                    ((Spinner) volumeSpinner).getSelectedView().setEnabled(true);
                    volumeSpinner.setEnabled(true);
                } else if (!hostBeeper.isChecked()) {
                    //   volumeSpinner.setVisibility(View.INVISIBLE);
                    ((Spinner) volumeSpinner).getSelectedView().setEnabled(false);
                    volumeSpinner.setEnabled(false);
                }
            }
        });
        volumeAdapter = ArrayAdapter.createFromResource(getActivity(), R.array.beeper_volume_array, R.layout.custom_spinner_layout);
        volumeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        volumeSpinner.setAdapter(volumeAdapter);
        if (RFIDController.beeperVolume != null && !("RE40".equalsIgnoreCase(model) || isCharmanderDevice()||"QC".equalsIgnoreCase(model))) {
            if (RFIDController.beeperVolume.equals(BEEPER_VOLUME.QUIET_BEEP)) {
                    hostBeeper.setChecked(false);
                    volumeSpinner.setEnabled(false);
                if (RFIDController.beeperspinner_status != 3)
                    volumeSpinner.setSelection(RFIDController.beeperspinner_status);

            } else if (!RFIDController.beeperVolume.equals(BEEPER_VOLUME.QUIET_BEEP)) {
                hostBeeper.setChecked(true);
                if (RFIDController.mConnectedReader != null) {
                    if (RFIDController.mConnectedReader.getHostName().startsWith("MC33")) {
                        volumeSpinner.setSelection(RFIDController.beeperVolume.getValue());
                        volumeSpinner.setEnabled(true);
                        sledBeeper.setChecked(false);
                        sledBeeper.setEnabled(false);

                    }else if (RFIDController.mConnectedReader.getHostName().startsWith("RFD40") || RFIDController.mConnectedReader.getHostName().startsWith("RFD90")) {
                        volumeSpinner.setSelection(RFIDController.beeperVolume.getValue());
                        volumeSpinner.setEnabled(true);
                        //hostBeeper.setChecked(false);
                        //hostBeeper.setEnabled(false);
                        //hostBeeper.setVisibility(View.INVISIBLE);

                    }
                }
            }
        }
        //setting Beeper for RE40 devices and Charmander device
        if (RFIDController.mConnectedReader != null && ("RE40".equalsIgnoreCase(model) || isCharmanderDevice()||"QC".equalsIgnoreCase(model))){
            BEEPER_VOLUME beeper_volume_host = null;
            try {
                beeper_volume_host = RFIDController.mConnectedReader.Config.getBeeperVolume();
                RFIDController.hostBeeperVolume = beeper_volume_host;
            } catch (InvalidUsageException e) {
                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
            } catch (OperationFailureException e) {
                beeper_volume_host = RFIDController.hostBeeperVolume;
                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
            }
            if (beeper_volume_host != null) {
                if (beeper_volume_host.equals(BEEPER_VOLUME.HIGH_BEEP))
                    hostBeeper.setChecked(true);
                else
                    hostBeeper.setChecked(false);
            }
        }

        if(RFIDController.mConnectedReader != null && RFIDController.mConnectedReader.ReaderCapabilities != null &&
                (RFIDController.mConnectedReader.ReaderCapabilities.getModelName().startsWith("RFD40") ||
                RFIDController.mConnectedReader.ReaderCapabilities.getModelName().startsWith("RFD90") )){
            sledBeeper.setEnabled(true);
            sledBeeperVolumeRow.setVisibility(View.VISIBLE);


            setSledVolumeControlsEnabled(sledBeeper.isChecked());

            sledBeeperVolumeSlider.setValue(sledBeeperVolume);
            sledBeeperVolumeValue.setText(String.valueOf(sledBeeperVolume));

            sledBeeperVolumeSlider.addOnChangeListener(
                    new Slider.OnChangeListener() {
                        @Override
                        public void onValueChange(Slider slider, float value,
                                                  boolean fromUser) {
                            sledBeeperVolume = (int) value;
                            sledBeeperVolumeValue
                                    .setText(String.valueOf(sledBeeperVolume));

                        }
                    });

            sledBeeperVolumeSlider.addOnSliderTouchListener(
                    new Slider.OnSliderTouchListener() {
                        @Override
                        public void onStartTrackingTouch(Slider slider) {
                            // optional
                        }

                        @Override
                        public void onStopTrackingTouch(Slider slider) {

                        }
                    });
        }
        if (RFIDController.mConnectedReader != null && !("RE40".equalsIgnoreCase(model) || isCharmanderDevice()||"QC".equalsIgnoreCase(model))) {
            BEEPER_VOLUME beeper_volume = null;
            try {
                beeper_volume = RFIDController.mConnectedReader.Config.getBeeperVolume();
                RFIDController.sledBeeperVolume = beeper_volume;

            } catch (InvalidUsageException e) {
                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
            } catch (OperationFailureException e) {

                beeper_volume = RFIDController.sledBeeperVolume;
                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
            }
            if (beeper_volume != null) {
                if (beeper_volume.equals(BEEPER_VOLUME.QUIET_BEEP)) {
                    sledBeeper.setChecked(false);
                    if (!RFIDController.beeperVolume.equals(BEEPER_VOLUME.QUIET_BEEP)) {
                        hostBeeper.setChecked(true);
                        volumeSpinner.setSelection(RFIDController.beeperVolume.getValue());
                        volumeSpinner.setEnabled(true);
                    } else {
                        volumeSpinner.setEnabled(false);
                        if (RFIDController.beeperspinner_status != 3)
                            volumeSpinner.setSelection(RFIDController.beeperspinner_status);
                    }
                } else if (!beeper_volume.equals(BEEPER_VOLUME.QUIET_BEEP)) {
                    sledBeeper.setChecked(true);
                    if (RFIDController.beeperVolume.equals(BEEPER_VOLUME.QUIET_BEEP)) {
                        volumeSpinner.setSelection(beeper_volume.getValue());
                        volumeSpinner.setEnabled(true);

                        if (sledBeeperVolumeSlider != null &&
                                sledBeeperVolumeValue != null) {
                            sledBeeperVolumeSlider.setValue(beeper_volume.getVolumeControl());
                            sledBeeperVolume = beeper_volume.getVolumeControl();
                            sledBeeperVolumeValue.setText(
                                    String.valueOf(beeper_volume.getVolumeControl())
                            );
                        }
                    } else {
                        volumeSpinner.setSelection(RFIDController.beeperVolume.getValue());
                        volumeSpinner.setEnabled(true);

                        if (sledBeeperVolumeSlider != null &&
                                sledBeeperVolumeValue != null) {
                            sledBeeperVolumeSlider.setValue(beeper_volume.getVolumeControl());
                            sledBeeperVolume = beeper_volume.getVolumeControl();
                            sledBeeperVolumeValue.setText(
                                    String.valueOf(beeper_volume.getVolumeControl())
                            );
                        }

                    }
                }
            }
        }


    }

    private void setSledVolumeControlsEnabled(boolean enabled) {
        sledBeeperVolumeSlider.setEnabled(enabled);
        sledBeeperVolumeValue.setEnabled(enabled);
    }


    String modelName = RFIDController.mConnectedDevice.getName();
    String model = RFIDController.mConnectedDevice.getDeviceCapability(modelName);

    //setting Beeper for RE40 devices and Charmander device
    private void setBeeperEnable(boolean bhostBeeper) {
        boolean bResult = false;
        if(!RFIDController.mIsInventoryRunning && !RFIDController.isLocatingTag){
            try {
                if (bhostBeeper) {
                    if (RFIDController.mConnectedReader != null) {
                        RFIDController.mConnectedReader.Config.setBeeperVolume(BEEPER_VOLUME.HIGH_BEEP);  // Code to enable the beeper
                        RFIDController.hostBeeperVolume = BEEPER_VOLUME.HIGH_BEEP;
                        bResult = true;
                    }
                } else {
                    if (RFIDController.mConnectedReader != null) {
                        RFIDController.mConnectedReader.Config.setBeeperVolume(BEEPER_VOLUME.QUIET_BEEP); // Code to disable the beeper
                        RFIDController.hostBeeperVolume = BEEPER_VOLUME.QUIET_BEEP;
                        bResult = true;
                    }
                }
            } catch (InvalidUsageException e) {
                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                bResult = false ;
            } catch (OperationFailureException e) {
                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                bResult = false ;
            }
            if(bResult){
                Toast.makeText(getActivity(), R.string.status_success_message, Toast.LENGTH_SHORT).show();
            }else{
                Toast.makeText(getActivity(), R.string.status_failure_message, Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(getActivity(), getString(R.string.status_failure_message)+ "\n" + "Operation In Progress", Toast.LENGTH_SHORT).show();
        }
    }

    public void onBackPressed() {
        if (RFIDController.mConnectedReader != null && !("RE40".equalsIgnoreCase(model) || isCharmanderDevice()||"QC".equalsIgnoreCase(model))) {
            if ((hostBeeper.isChecked() && RFIDController.beeperVolume != null && RFIDController.beeperVolume.getValue() != volumeSpinner.getSelectedItemPosition())
                    || (sledBeeper.isEnabled() && sledBeeper.isChecked() && RFIDController.sledBeeperVolume != null && ((RFIDController.sledBeeperVolume.getValue() != volumeSpinner.getSelectedItemPosition()) || (RFIDController.sledBeeperVolume.getVolumeControl() != sledBeeperVolume) )
            )) {
                new Task_SetVolume(volumeSpinner.getSelectedItemPosition()).execute();
            } else if ((RFIDController.mConnectedReader.getHostName().startsWith("RFD40") || RFIDController.mConnectedReader.getHostName().startsWith("RFD90") || RFIDController.mConnectedReader.getHostName().startsWith("RFD8500"))
                    && (hostBeeper.isChecked() && RFIDController.beeperVolume.getValue() == volumeSpinner.getSelectedItemPosition()
                    && !sledBeeper.isChecked()) || (sledBeeper.isChecked() && RFIDController.sledBeeperVolume.getValue() == volumeSpinner.getSelectedItemPosition()
                    && !hostBeeper.isChecked())
                    ) {
                if (RFIDController.beeperVolume.getValue() != volumeSpinner.getSelectedItemPosition()) {
                    if(getActivity() instanceof SettingsDetailActivity)
                        ((SettingsDetailActivity) getActivity()).callBackPressed();
                    else if(getActivity() instanceof ActiveDeviceActivity) {
                        ((ActiveDeviceActivity) getActivity()).callBackPressed();
                        ((ActiveDeviceActivity) getActivity()).loadNextFragment(MAIN_RFID_SETTINGS_TAB);
                    }
                } else if (RFIDController.sledBeeperVolume.getValue() != volumeSpinner.getSelectedItemPosition()) {
                    if(getActivity() instanceof SettingsDetailActivity)
                        ((SettingsDetailActivity) getActivity()).callBackPressed();
                    else if(getActivity() instanceof ActiveDeviceActivity) {
                        ((ActiveDeviceActivity) getActivity()).callBackPressed();
                        ((ActiveDeviceActivity) getActivity()).loadNextFragment(MAIN_RFID_SETTINGS_TAB);
                    }
                } else {
                    new Task_SetVolume(volumeSpinner.getSelectedItemPosition()).execute();
                }
            } else if ((!hostBeeper.isChecked() && RFIDController.beeperVolume != null && !RFIDController.beeperVolume.equals(BEEPER_VOLUME.QUIET_BEEP)) || (sledBeeper.isEnabled() && !sledBeeper.isChecked() && RFIDController.sledBeeperVolume != null && !RFIDController.sledBeeperVolume.equals(BEEPER_VOLUME.QUIET_BEEP))) {
                RFIDController.beeperspinner_status = volumeSpinner.getSelectedItemPosition();
                new Task_SetVolume(Constants.QUIET_BEEPER).execute();


            } else {
                if(getActivity() instanceof SettingsDetailActivity)
                    ((SettingsDetailActivity) getActivity()).callBackPressed();
                if(getActivity() instanceof ActiveDeviceActivity) {
                    ((ActiveDeviceActivity) getActivity()).callBackPressed();
                    ((ActiveDeviceActivity) getActivity()).loadNextFragment(MAIN_RFID_SETTINGS_TAB);
                }

            }
        } else {
            boolean bhostBeeper = false;
            bhostBeeper = hostBeeper.isChecked();
            if((hostBeeper.isChecked() && RFIDController.hostBeeperVolume== BEEPER_VOLUME.HIGH_BEEP)){
                // No change in setting
            }else if((hostBeeper.isChecked() == false && RFIDController.hostBeeperVolume==BEEPER_VOLUME.QUIET_BEEP)){
                // No change in setting
            }else{
                setBeeperEnable(bhostBeeper);
            }

            if(getActivity() instanceof SettingsDetailActivity)
                ((SettingsDetailActivity) getActivity()).callBackPressed();
            if(getActivity() instanceof ActiveDeviceActivity) {
                ((ActiveDeviceActivity) getActivity()).callBackPressed();
                ((ActiveDeviceActivity) getActivity()).loadNextFragment(MAIN_RFID_SETTINGS_TAB);
            }
        }
    }

    /**
     * method to update battery screen when device got disconnected
     */
    public void deviceDisconnected() {
        hostBeeper.setChecked(false);
    }

    private class Task_SetVolume extends AsyncTask<Void, Void, Boolean> {
        private final int volume;
        private OperationFailureException operationFailureException;
        private InvalidUsageException invalidUsageException;
        private ProgressDialog progressDialog;
        private int percantageVolume = 100;
        private boolean bsledBeeper = false;
        private boolean bhostBeeper = false;
        private boolean bsledBeeperEnable = false;

        public Task_SetVolume(int volume) {
            this.volume = volume;
        }

        @Override
        protected void onPreExecute() {
            bsledBeeper = sledBeeper.isChecked();
            bhostBeeper = hostBeeper.isChecked();
            bsledBeeperEnable = sledBeeper.isEnabled();
            progressDialog = new CustomProgressDialog(getActivity(), getString(R.string.beeper_volume_title));
            progressDialog.show();
        }

        @Override
        protected Boolean doInBackground(Void... params) {
            Boolean bResult = true;

            try {

                if (RFIDController.mConnectedReader != null) {
                    if (bsledBeeperEnable) {
                        if (bsledBeeper) {

                            // disable beeper get/set from/to reader
                            if (volume == 0) {
                                RFIDController.sledBeeperVolume = BEEPER_VOLUME.HIGH_BEEP;
                                RFIDController.sledBeeperVolume.setVolumeControl(sledBeeperVolume);
                                RFIDController.mConnectedReader.Config.setBeeperVolume(RFIDController.sledBeeperVolume);
                            }
                            if (volume == 1) {
                                RFIDController.sledBeeperVolume = BEEPER_VOLUME.MEDIUM_BEEP;
                                RFIDController.sledBeeperVolume.setVolumeControl(sledBeeperVolume);
                                RFIDController.mConnectedReader.Config.setBeeperVolume(RFIDController.sledBeeperVolume);
                            }
                            if (volume == 2) {
                                RFIDController.sledBeeperVolume = BEEPER_VOLUME.LOW_BEEP;
                                RFIDController.sledBeeperVolume.setVolumeControl(sledBeeperVolume);
                                RFIDController.mConnectedReader.Config.setBeeperVolume(RFIDController.sledBeeperVolume);
                            }
                            if (volume == 3) {
                                RFIDController.mConnectedReader.Config.setBeeperVolume(BEEPER_VOLUME.QUIET_BEEP);
                                RFIDController.sledBeeperVolume = BEEPER_VOLUME.QUIET_BEEP;
                            }

                        } else {

                            if (RFIDController.mConnectedReader != null) {
                                RFIDController.mConnectedReader.Config.setBeeperVolume(BEEPER_VOLUME.QUIET_BEEP);
                            }

                        }
                    }
                    //
                    SharedPreferences sharedPref = getActivity().getSharedPreferences(getString(R.string.pref_beeper), getContext().MODE_PRIVATE);
                    SharedPreferences.Editor editor = sharedPref.edit();
                    if (bhostBeeper) {
                        if (volume == 0) {
                            RFIDController.beeperVolume = BEEPER_VOLUME.HIGH_BEEP;
                            percantageVolume = 100;
                        }
                        if (volume == 1) {
                            RFIDController.beeperVolume = BEEPER_VOLUME.MEDIUM_BEEP;
                            percantageVolume = 75;
                        }
                        if (volume == 2) {
                            RFIDController.beeperVolume = BEEPER_VOLUME.LOW_BEEP;
                            percantageVolume = 50;
                        }
                        if (volume == 3) {
                            RFIDController.beeperVolume = BEEPER_VOLUME.QUIET_BEEP;
                            percantageVolume = 0;
                        }
                        editor.putInt(getString(R.string.beeper_volume), volume);

                    } else {
                        RFIDController.beeperVolume = BEEPER_VOLUME.QUIET_BEEP;
                        percantageVolume = 0;
                        editor.putInt(getString(R.string.beeper_volume), 3);

                    }
                    editor.commit();
                }

            } catch (InvalidUsageException e) {
                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                invalidUsageException = e;
                bResult = false;
            } catch (OperationFailureException e) {
                if( e!= null && e.getStackTrace().length>0){ Log.e(TAG, e.getStackTrace()[0].toString()); }
                operationFailureException = e;
                bResult = false;
            }
            return bResult;
        }

        @Override
        protected void onPostExecute(Boolean result) {
            progressDialog.cancel();
            try {
                if (!result) {
                    if (invalidUsageException != null) {
                        if(getActivity() instanceof SettingsDetailActivity)
                            ((SettingsDetailActivity) getActivity()).sendNotification(Constants.ACTION_READER_STATUS_OBTAINED, getString(R.string.status_failure_message) + "\n" + invalidUsageException.getVendorMessage());
                        else if(getActivity() instanceof ActiveDeviceActivity)
                            ((ActiveDeviceActivity) getActivity()).sendNotification(Constants.ACTION_READER_STATUS_OBTAINED, getString(R.string.status_failure_message) + "\n" + invalidUsageException.getVendorMessage());
                    }
                    if (operationFailureException != null) {
                        if(getActivity() instanceof SettingsDetailActivity)
                            ((SettingsDetailActivity) getActivity()).sendNotification(Constants.ACTION_READER_STATUS_OBTAINED, getString(R.string.status_failure_message) + "\n" + operationFailureException.getVendorMessage());
                        else if(getActivity() instanceof ActiveDeviceActivity)
                            ((ActiveDeviceActivity) getActivity()).sendNotification(Constants.ACTION_READER_STATUS_OBTAINED, getString(R.string.status_failure_message) + "\n" + operationFailureException.getVendorMessage());
                    }

                } else {
                    int streamType = AudioManager.STREAM_DTMF;
                    RFIDController.toneGenerator = new ToneGenerator(streamType, percantageVolume);
                    Toast.makeText(getActivity(), R.string.status_success_message, Toast.LENGTH_SHORT).show();

                }
            } catch (RuntimeException exception) {
                //exception.printStackTrace();
                RFIDController.toneGenerator = null;
            }
            super.onPostExecute(result);
            if(getActivity() instanceof SettingsDetailActivity)
                ((SettingsDetailActivity) getActivity()).callBackPressed();

            if(getActivity() instanceof ActiveDeviceActivity)
                ((ActiveDeviceActivity)getActivity()).loadNextFragment(MAIN_RFID_SETTINGS_TAB);

        }
    }

}
